import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eefbfa",
          100: "#d4f5f1",
          200: "#a9ebe4",
          300: "#75dcd2",
          400: "#3fc4b6",
          500: "#1ea89b",
          600: "#15877e",
          700: "#146c66",
          800: "#145651",
          900: "#134744",
          950: "#052a28",
        },
        ink: {
          50: "#f4f6f8",
          100: "#e5e9ee",
          200: "#c9d1db",
          300: "#a3aebe",
          400: "#76839a",
          500: "#5a677f",
          600: "#475269",
          700: "#3a4356",
          800: "#262d3a",
          900: "#161b25",
          950: "#0a0d13",
        },
        accent: {
          400: "#ffb547",
          500: "#ff9f1c",
          600: "#e6870a",
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        display: ["var(--font-poppins)", "system-ui", "sans-serif"],
      },
      backgroundImage: {
        "grid-pattern":
          "linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)",
        "hero-radial":
          "radial-gradient(circle at 20% 20%, rgba(31,168,155,0.35), transparent 40%), radial-gradient(circle at 80% 0%, rgba(255,159,28,0.25), transparent 35%)",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-12px)" },
        },
        "pulse-ring": {
          "0%": { transform: "scale(0.9)", opacity: "0.7" },
          "70%": { transform: "scale(1.4)", opacity: "0" },
          "100%": { transform: "scale(0.9)", opacity: "0" },
        },
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        "pulse-ring": "pulse-ring 2.5s cubic-bezier(0.4,0,0.6,1) infinite",
        marquee: "marquee 30s linear infinite",
      },
    },
  },
  plugins: [],
};

export default config;
