import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import AnimatedSection from "@/components/AnimatedSection";

export default function CTASection() {
  return (
    <section className="section-container py-20">
      <AnimatedSection>
        <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-brand-700/40 via-ink-900 to-ink-950 px-6 py-14 text-center md:px-16">
          <div className="absolute -top-20 left-1/2 h-64 w-64 -translate-x-1/2 rounded-full bg-brand-400/20 blur-3xl" />
          <h2 className="relative font-display text-3xl font-bold text-white md:text-4xl">
            Ready to build a support team that never sleeps?
          </h2>
          <p className="relative mx-auto mt-4 max-w-xl text-ink-300">
            Whether you&apos;re a growing Indian startup or an international
            business looking for a reliable outsourcing partner, Pickiworld is
            ready to plug in.
          </p>
          <div className="relative mt-8 flex flex-wrap items-center justify-center gap-4">
            <Link href="/contact" className="btn-primary">
              Request a Free Quote <ArrowUpRight size={18} />
            </Link>
            <Link href="/services" className="btn-outline">
              Explore Services
            </Link>
          </div>
        </div>
      </AnimatedSection>
    </section>
  );
}
