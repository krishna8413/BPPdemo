"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import { gsap } from "gsap";
import { ArrowUpRight, Globe2, PhoneCall } from "lucide-react";
import LottiePlayer from "@/components/LottiePlayer";
import StatsCounter from "@/components/StatsCounter";

export default function Hero() {
  const rootRef = useRef<HTMLDivElement>(null);
  const blobRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: "power3.out" } });
      tl.from(".hero-eyebrow", { opacity: 0, y: 16, duration: 0.6 })
        .from(".hero-title-line", { opacity: 0, y: 40, duration: 0.8, stagger: 0.12 }, "-=0.3")
        .from(".hero-copy", { opacity: 0, y: 20, duration: 0.7 }, "-=0.4")
        .from(".hero-cta", { opacity: 0, y: 20, duration: 0.6, stagger: 0.1 }, "-=0.4")
        .from(".hero-art", { opacity: 0, scale: 0.85, duration: 0.9 }, "-=0.7");

      gsap.to(blobRef.current, {
        y: 40,
        x: 20,
        duration: 8,
        ease: "sine.inOut",
        repeat: -1,
        yoyo: true,
      });
    }, rootRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={rootRef}
      className="relative overflow-hidden bg-hero-radial bg-ink-950 pt-32 pb-20 md:pt-44 md:pb-28"
    >
      <div className="absolute inset-0 bg-grid-pattern bg-[size:40px_40px] opacity-40" />
      <div
        ref={blobRef}
        className="absolute -top-24 right-[-10%] h-[420px] w-[420px] rounded-full bg-brand-500/20 blur-3xl"
      />

      <div className="section-container relative grid gap-12 md:grid-cols-2 md:items-center">
        <div>
          <span className="hero-eyebrow inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium uppercase tracking-wide text-brand-300">
            <Globe2 size={14} /> Domestic &amp; International BPO Partner
          </span>

          <h1 className="mt-6 font-display text-4xl font-bold leading-tight text-white md:text-5xl lg:text-6xl">
            <span className="hero-title-line block">Outsource Smarter.</span>
            <span className="hero-title-line block">
              Scale <span className="text-gradient">Your Support</span>
            </span>
            <span className="hero-title-line block">Without Limits.</span>
          </h1>

          <p className="hero-copy mt-6 max-w-lg text-base text-ink-300 md:text-lg">
            Pickiworld OPC Pvt Ltd builds dedicated voice, chat, and back-office
            teams for businesses across India and around the world — trained
            fast, priced fairly, and available whenever your customers are.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Link href="/contact" className="hero-cta btn-primary">
              Get a Free Consultation <ArrowUpRight size={18} />
            </Link>
            <a href="tel:+919000000000" className="hero-cta btn-outline">
              <PhoneCall size={16} /> Talk to Us
            </a>
          </div>

          <div className="mt-10">
            <StatsCounter />
          </div>
        </div>

        <div className="hero-art relative mx-auto flex items-center justify-center">
          <div className="relative h-72 w-72 md:h-96 md:w-96">
            <div className="absolute inset-0 animate-float">
              <LottiePlayer path="/lottie/orbit.json" className="h-full w-full" />
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="glass-card flex h-32 w-32 flex-col items-center justify-center rounded-full text-center md:h-40 md:w-40">
                <span className="font-display text-2xl font-bold text-white md:text-3xl">24/7</span>
                <span className="text-[11px] uppercase tracking-wide text-ink-300">Global Support</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
