import Link from "next/link";
import { Linkedin, Twitter, Facebook, Instagram, Mail, Phone, MapPin } from "lucide-react";
import { siteConfig } from "@/lib/siteConfig";
import { services } from "@/lib/data";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-white/10 bg-ink-950">
      <div className="section-container py-14">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-4">
          <div>
            <Link href="/" className="flex items-center gap-2">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-brand-400 to-accent-500 font-display font-bold text-ink-950">
                P
              </span>
              <span className="font-display font-bold text-lg text-white">
                Picki<span className="text-brand-400">world</span>
              </span>
            </Link>
            <p className="mt-4 text-sm text-ink-300 leading-relaxed">
              {siteConfig.name} — outsourced customer support and back-office
              teams for domestic and international businesses.
            </p>
            <div className="mt-5 flex gap-3">
              {[
                { href: siteConfig.social.linkedin, icon: Linkedin },
                { href: siteConfig.social.twitter, icon: Twitter },
                { href: siteConfig.social.facebook, icon: Facebook },
                { href: siteConfig.social.instagram, icon: Instagram },
              ].map(({ href, icon: SocialIcon }, i) => (
                <a
                  key={i}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-ink-300 hover:border-brand-400 hover:text-brand-400 transition-colors"
                >
                  <SocialIcon size={16} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-display font-semibold text-white mb-4">Services</h4>
            <ul className="space-y-2.5 text-sm text-ink-300">
              {services.slice(0, 6).map((s) => (
                <li key={s.slug}>
                  <Link href={`/services#${s.slug}`} className="hover:text-brand-400 transition-colors">
                    {s.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold text-white mb-4">Company</h4>
            <ul className="space-y-2.5 text-sm text-ink-300">
              <li><Link href="/about" className="hover:text-brand-400 transition-colors">About Us</Link></li>
              <li><Link href="/industries" className="hover:text-brand-400 transition-colors">Industries</Link></li>
              <li><Link href="/careers" className="hover:text-brand-400 transition-colors">Careers</Link></li>
              <li><Link href="/contact" className="hover:text-brand-400 transition-colors">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold text-white mb-4">Get in Touch</h4>
            <ul className="space-y-3 text-sm text-ink-300">
              <li className="flex items-start gap-2.5">
                <MapPin size={16} className="mt-0.5 shrink-0 text-brand-400" />
                <span>{siteConfig.contact.address}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail size={16} className="shrink-0 text-brand-400" />
                <a href={`mailto:${siteConfig.contact.email}`} className="hover:text-brand-400 transition-colors">
                  {siteConfig.contact.email}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone size={16} className="shrink-0 text-brand-400" />
                <a href={`tel:${siteConfig.contact.phoneIndia.replace(/\s/g, "")}`} className="hover:text-brand-400 transition-colors">
                  {siteConfig.contact.phoneIndia} (India)
                </a>
              </li>
              <li className="flex items-center gap-2.5 pl-[26px]">
                <a href={`tel:${siteConfig.contact.phoneIntl.replace(/\s/g, "")}`} className="hover:text-brand-400 transition-colors">
                  {siteConfig.contact.phoneIntl} (Intl.)
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-3 border-t border-white/10 pt-6 text-xs text-ink-400 md:flex-row md:items-center md:justify-between">
          <p>© {year} {siteConfig.name}. All rights reserved.</p>
          <p>Serving clients across India, the US, UK, Canada, Australia & the Middle East.</p>
        </div>
      </div>
    </footer>
  );
}
